1. 将mNetAssist-release-amd64.deb文件放到Ubuntu中
2. 使用终端安装
	sudo dpkg -i mNetAssist-release-amd64.deb
3. 在Ubuntu左上角搜索“网络调试助手”，单击运行